from django.urls import path
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
    TokenVerifyView,
)
from .views import RegisterView, LoginView, LogoutView, ChangePasswordView, PasswordResetRequestView, PasswordResetConfirmView, ProfileView, ProfileUpdateView, JournalEntryListCreateView, JournalEntryRetrieveUpdateDestroyView, CategoryListCreateView, CategoryRetrieveUpdateDestroyView, JournalEntryCategoryListCreateView, JournalEntryCategoryRetrieveUpdateDestroyView

urlpatterns = [
    path('register/', RegisterView.as_view(), name='register'),
    path('login/', LoginView.as_view(), name='login'),
    path('logout/', LogoutView.as_view(), name='logout'),
    path('token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('token/verify/', TokenVerifyView.as_view(), name='token_verify'),
    path('change-password/', ChangePasswordView.as_view(), name='change-password'),
    path('password-reset/', PasswordResetRequestView.as_view(), name='password_reset_request'),
    path('password-reset/confirm/<str:uidb64>/<str:token>/', PasswordResetConfirmView.as_view(), name='password_reset_confirm'),
    path('profile/', ProfileView.as_view(), name='profile'),
    path('profile/update/', ProfileUpdateView.as_view(), name='profile-update'),

   
    path('journal-entries/', JournalEntryListCreateView.as_view(), name='journal-entry-list-create'),
    path('journal-entries/<int:pk>/', JournalEntryRetrieveUpdateDestroyView.as_view(), name='journal-entry-retrieve-update-destroy'),

   
    path('categories/', CategoryListCreateView.as_view(), name='category-list-create'),
    path('categories/<int:pk>/', CategoryRetrieveUpdateDestroyView.as_view(), name='category-retrieve-update-destroy'),

    
    path('journal-entry-categories/', JournalEntryCategoryListCreateView.as_view(), name='journal-entry-category-list-create'),
    path('journal-entry-categories/<int:pk>/', JournalEntryCategoryRetrieveUpdateDestroyView.as_view(), name='journal-entry-category-retrieve-update-destroy'),
]