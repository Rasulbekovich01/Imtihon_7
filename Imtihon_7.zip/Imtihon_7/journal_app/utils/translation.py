from django.utils.translation import gettext as _

def translate_message(message, lang='uz'):
    if lang == 'en':
        if message == "Parol muvaffaqiyatli o'zgartirildi":
            return "Password changed successfully"
        elif message == "Foydalanuvchi topilmadi":
            return "User not found"
        
    return message  